This folder is just a placeholder for Okteto, because of:
<img src="https://i.imgur.com/ZGATgDR.jpeg" alt="proofs">